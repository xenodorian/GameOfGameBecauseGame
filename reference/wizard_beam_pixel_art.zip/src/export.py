"""Export the wizard beam animation: background GIF plus transparent asset pack."""
import importlib, json, os, sys
import numpy as np
from PIL import Image

OUT = sys.argv[1] if len(sys.argv) > 1 else 'pack'
os.makedirs(OUT, exist_ok=True)

r = importlib.import_module('render')
r.main(os.path.join(OUT, 'wizard_beam_with_background.gif'))  # also writes sheet.png in cwd

r = importlib.reload(r)  # reset RNG and particles so both versions match frame for frame
W, H, S, NF = r.W, r.H, r.SCALE, r.NF
pal = np.round(r.P * 255).astype(np.uint8)
durs = [70 if f in (15, 16, 17) else 50 if f == 21 else 40 for f in range(NF)]
os.makedirs(f'{OUT}/frames_1x', exist_ok=True); os.makedirs(f'{OUT}/frames_4x', exist_ok=True)
rgba = []
for f in range(NF):
    idx, A = r.render(f, nobg=True)
    rgb = pal[idx].copy()
    soft = (A > 0) & (A < 1)
    rgb[soft] = np.array([0x2a, 0x90, 0xff], np.uint8)
    im = Image.fromarray(np.dstack([rgb, np.round(A * 255).astype(np.uint8)]), 'RGBA')
    rgba.append(im)
    im.save(f'{OUT}/frames_1x/frame_{f:02d}.png')
    im.resize((W * S, H * S), Image.NEAREST).save(f'{OUT}/frames_4x/frame_{f:02d}.png')

cols = 10; rows = (NF + cols - 1) // cols
sheet = Image.new('RGBA', (W * cols, H * rows), (0, 0, 0, 0))
for i, im in enumerate(rgba): sheet.paste(im, ((i % cols) * W, (i // cols) * H))
sheet.save(f'{OUT}/spritesheet_1x.png')

big = [im.resize((W * S, H * S), Image.NEAREST) for im in rgba]
big[0].save(f'{OUT}/wizard_beam_transparent.png', save_all=True, append_images=big[1:],
            duration=durs, loop=0, disposal=1, format='PNG')  # APNG, keeps soft glow alpha

# GIF only supports on/off transparency: drop glow pixels under 50% alpha, use index 255 as clear
gif = []
pl = pal.flatten().tolist(); pl += [0] * (768 - len(pl))
for im in big:
    a = np.array(im)
    idx = np.argmin(((a[..., :3].reshape(-1, 1, 3).astype(int) - pal[None].astype(int)) ** 2).sum(-1), 1).reshape(a.shape[:2])
    idx = np.where(a[..., 3] >= 128, idx, 255).astype(np.uint8)
    g = Image.fromarray(idx, 'P'); g.putpalette(pl); g.info['transparency'] = 255
    gif.append(g)
gif[0].save(f'{OUT}/wizard_beam_transparent.gif', save_all=True, append_images=gif[1:],
            duration=durs, loop=0, disposal=2, transparency=255, optimize=False)

meta = dict(
    frame_size_1x=[W, H], scale_of_4x_assets=S, frame_count=NF, fps_nominal=25,
    durations_ms=durs, total_ms=sum(durs), loop=True,
    spritesheet=dict(file='spritesheet_1x.png', columns=cols, rows=rows, order='row-major, left to right'),
    coordinates_1x=dict(floor_y=r.FY, wizard_feet=[r.WX + 8, r.FY], beam_axis_y=r.SHOULDER[1],
                        beam_impact_x=r.XI, note='beam starts at the staff orb, about x=61 once the swing settles'),
    phases=dict(charge=[0, 9], windup=[10, 17], swing_smear=[18, 20], fire_flash_and_extend=[21, 23],
                sustain=[24, 45], dissipate=[46, 51], recover=[52, 59]),
    alpha='PNG/APNG frames keep soft glow alpha; the GIF uses 1-bit transparency so faint glow is dropped')
json.dump(meta, open(f'{OUT}/animation.json', 'w'), indent=2)
print('done')
