import math, random
import numpy as np
from PIL import Image

W, H, FY, SCALE = 192, 100, 86, 4
NF = 60
rng = random.Random(7)

def hx(s):
    s = s.lstrip('#'); return tuple(int(s[i:i+2], 16) / 255 for i in (0, 2, 4))

PAL = [hx(c) for c in (
    '08060e', '0b0a14', '14122a', '1d1a3a', '2a2550', '3a3468', '4c4580',   # bg / stone
    '1a1830', '262244', '332e58',                                          # floor
    '18204a', '1c2a5c', '25408a', '3060b0',                                # lit stone
    '2b1d4e', '46307a', '6a4aa8', '8f6fd0',                                # robe
    'c8a040', 'f0d070', 'e0a878', 'b07850',                                # gold, skin
    'd8d8e8', 'a0a0b8', '6a6a88', '3a2414', '6a4022', '9a6434', '4a2a18',  # beard, wood, boots
    '0a1a4a', '10307a', '1a5ad0', '2a90ff', '5ad0ff', 'a8f0ff', 'ffffff',  # energy ramp
    '5a2010', 'b04818', 'f08828', 'ffd060')]                               # torch
P = np.array(PAL)
C = {k: hx(v) for k, v in dict(
    O='08060e', a='2b1d4e', b='46307a', c='6a4aa8', h='8f6fd0', g='c8a040', G='f0d070',
    s='e0a878', S='b07850', w='d8d8e8', W='a0a0b8', e='08060e', d='4a2a18').items()}
RAMP = [(0.30, hx('1a5ad0')), (0.50, hx('2a90ff')), (0.66, hx('5ad0ff')),
        (0.80, hx('a8f0ff')), (0.92, hx('ffffff'))]
BAYER = np.array([[0, 8, 2, 10], [12, 4, 14, 6], [3, 11, 1, 9], [15, 7, 13, 5]]) / 16.0
BY = np.tile(BAYER, (H // 4 + 1, W // 4 + 1))[:H, :W]
YY, XX = np.mgrid[0:H, 0:W].astype(float)

SPRITE = """\
......OO
.....ObO
......ObO
......OcbO
.....OabcO
.....OabccO
....OaabccO
....OaabbccO
...OaaabbbcO
...OaaabbbccO
..OggggggggggO
OOaaaaabbbbbbccOO
.OOOOaSSssssOOOO
....OaSssesssO
....OaSsssssssO
....OaWwwwwwwO
....OaWwwWwwwwO
...OaaWwwwWwwwO
...OaabWwwwWwwO
...OabbcWwwwwO
..OaabbcWWwwO
..OaabbccWwO
..OaabbbccWO
..OagggGgggO
.OaaabbbcccO
.OaaabbbbcccO
.OaaabbbbcccO
.OaaabbbbbcccO
OaaaabbbbbcccO
OaaaabbbbbbcccO
OaaaabbbbbbcccO
OaaaaabbbbbbcccO
OaaaaabbbbbbccccO
OOaaaaabbbbbbcccO
.OOOOOOOOOOOOOOOO
...OddO...OddO"""
SPR = SPRITE.split('\n')
WX, WY = 24, 50
SHOULDER = (WX + 9, WY + 19)

# ---------- background ----------
def make_bg():
    bg = np.zeros((H, W, 3))
    r = random.Random(3)
    for y in range(H):
        for x in range(W):
            if y >= FY:
                ry = y - FY
                row = ry // 5
                off = (row * 7) % 16
                edge = ry % 5 == 0 or (x + off) % 16 == 0
                c = '1a1830' if edge else ('262244' if (x + off) // 16 % 3 else '332e58')
                if y == FY: c = '332e58'
            else:
                row = y // 6
                off = 6 if row % 2 else 0
                mort = y % 6 == 5 or (x + off) % 12 == 11
                c = '0b0a14' if mort else ('1d1a3a' if ((x + off) // 12 + row) % 3 else '14122a')
                if not mort and y % 6 == 0: c = '2a2550' if c == '1d1a3a' else '1d1a3a'
                if y < 18 and not mort: c = '14122a' if c != '0b0a14' else c
            bg[y, x] = hx(c)
    for _ in range(14):  # cracks
        x, y = r.randrange(W - 20), r.randrange(10, FY - 4)
        for k in range(r.randrange(3, 7)):
            if 0 <= y < FY: bg[y, x] = hx('0b0a14')
            x += 1; y += r.choice((-1, 0, 1))
    for y in range(0, FY):  # pillar
        for x in range(178, W):
            row = y // 8
            mort = y % 8 == 7 or (x - 178 + (4 if row % 2 else 0)) % 9 == 8
            c = '1d1a3a' if mort else ('3a3468' if x > 179 else '4c4580')
            if x == 178: c = '08060e'
            bg[y, x] = hx(c)
    for x in range(8, 13): bg[38, x] = hx('3a2414')  # torch bracket
    for y in range(36, 42): bg[y, 10] = hx('6a4022')
    return bg
BG = make_bg()

# ---------- helpers ----------
def line(x0, y0, x1, y1):
    x0, y0, x1, y1 = map(lambda v: int(round(v)), (x0, y0, x1, y1))
    dx, dy = abs(x1 - x0), -abs(y1 - y0)
    sx, sy = (1 if x0 < x1 else -1), (1 if y0 < y1 else -1)
    err, pts = dx + dy, []
    while True:
        pts.append((x0, y0))
        if x0 == x1 and y0 == y1: return pts
        e2 = 2 * err
        if e2 >= dy: err += dy; x0 += sx
        if e2 <= dx: err += dx; y0 += sy

def ss(t): t = min(max(t, 0), 1); return t * t * (3 - 2 * t)

KEYS = [(0, -78, -20, 0), (9, -78, -20, 0), (15, -160, -128, -1), (17, -163, -130, -1),
        (18, -105, -85, 0), (19, -40, -30, 1), (20, 16, 16, 1), (21, 9, 8, 1),
        (24, 0, 2, 0), (45, 0, 2, 0), (51, -6, -2, 0), (59, -78, -20, 0)]
def pose(f):
    for (f0, t0, p0, l0), (f1, t1, p1, l1) in zip(KEYS, KEYS[1:]):
        if f0 <= f <= f1:
            u = (f - f0) / (f1 - f0)
            u = u if 17 <= f0 < 21 else ss(u)
            return t0 + (t1 - t0) * u, p0 + (p1 - p0) * u, round(l0 + (l1 - l0) * u)
    return KEYS[-1][1:]

def staff_geom(theta, phi, lean):
    sx, sy = SHOULDER[0] + lean, SHOULDER[1]
    hxp = sx + 7 * math.cos(math.radians(phi)); hyp = sy + 7 * math.sin(math.radians(phi))
    d = (math.cos(math.radians(theta)), math.sin(math.radians(theta)))
    top = (hxp + 21 * d[0], hyp + 21 * d[1]); butt = (hxp - 10 * d[0], hyp - 10 * d[1])
    return (sx, sy), (hxp, hyp), top, butt, d

# ---------- particles ----------
parts = []
def spawn(x, y, vx, vy, life, e, g=0.0, kind='spark'):
    parts.append(dict(x=x, y=y, vx=vx, vy=vy, life=life, max=life, e=e, g=g, kind=kind))

def bolt(xa, ya, xb, yb, amp, depth=4):
    pts = [(xa, ya), (xb, yb)]
    for _ in range(depth):
        new = [pts[0]]
        for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
            new += [((x0 + x1) / 2 + rng.uniform(-amp, amp) * 0.4, (y0 + y1) / 2 + rng.uniform(-amp, amp)), (x1, y1)]
        pts, amp = new, amp * 0.55
    return pts

def raster_bolt(E, pts, core=0.97, glow=0.52):
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        for x, y in line(x0, y0, x1, y1):
            for ox, oy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                if 0 <= x + ox < W and 0 <= y + oy < H: E[y + oy, x + ox] = max(E[y + oy, x + ox], glow)
            if 0 <= x < W and 0 <= y < H: E[y, x] = max(E[y, x], core)

XI = 178
def beam_params(f):
    if f < 21 or f > 51: return None
    ext = {21: 0.3, 22: 0.62, 23: 0.88}.get(f, 1.0)
    env = 1.0 if f <= 45 else 1 - (f - 45) / 6
    if f == 21: env = 0.7
    return ext, env

# ---------- frame ----------
def render(f, nobg=False):
    theta, phi, lean = pose(f)
    bob = 1 if (f < 10 and (f // 4) % 2) or (f >= 54 and (f // 3) % 2) else 0
    (sx, sy), (hxp, hyp), top, butt, d = staff_geom(theta, phi, lean)
    sy += bob; hyp += bob; top = (top[0], top[1] + bob); butt = (butt[0], butt[1] + bob)
    ox, oy = top
    E = np.zeros((H, W)); L = np.zeros((H, W))
    bp = beam_params(f)
    beam_on = bp is not None
    glow = 0.0

    # orb charge / glow
    if f < 21:
        charge = 0.35 + 0.65 * ss(f / 17)
        pulse = 0.15 * math.sin(f * 1.3)
        rad = 2.5 + 3.5 * charge + pulse * 3
        D = np.hypot(XX - ox, YY - oy)
        E = np.maximum(E, np.clip(1.0 - D / rad, 0, 1) * (0.7 + 0.35 * charge))
        L += 0.6 * charge * np.exp(-D / 22)
        glow = charge * 0.6
        if f < 18 and f % 1 == 0:
            for _ in range(2 + f // 5):
                a = rng.uniform(0, 2 * math.pi); r = rng.uniform(16, 26)
                spawn(ox + r * math.cos(a), oy + r * math.sin(a), 0, 0, rng.randint(6, 10), rng.uniform(0.55, 0.9), kind='mote')
        if 11 <= f <= 17:  # rotating rune ring
            n = 10; R = 9 + (17 - f) * 0.6
            for k in range(n):
                a = k * 2 * math.pi / n + f * 0.35
                x, y = int(round(ox + R * math.cos(a))), int(round(oy + R * math.sin(a)))
                if 0 <= x < W and 0 <= y < H: E[y, x] = max(E[y, x], 0.85 if k % 2 else 0.6)
        if 18 <= f <= 20:  # smear arc of the orb
            pt, pp, pl = pose(f - 1)
            prev = staff_geom(pt, pp, pl)[2]
            for k in range(12):
                u = k / 11
                a0 = math.radians(pt + (theta - pt) * u)
                hx_ = hxp + (prev[0] - hxp) * 0  # pivot approx at hand
                x = hxp + 21 * math.cos(a0); y = hyp + 21 * math.sin(a0)
                for rr in range(-2, 3):
                    for ry in range(-2, 3):
                        if rr * rr + ry * ry <= 4 + u * 2:
                            xi, yi = int(x + rr), int(y + ry)
                            if 0 <= xi < W and 0 <= yi < H:
                                E[yi, xi] = max(E[yi, xi], 0.32 + 0.6 * u)
                for k2 in range(6, 20, 3):  # faint wedge
                    xi, yi = int(hxp + k2 * math.cos(a0)), int(hyp + k2 * math.sin(a0))
                    if 0 <= xi < W and 0 <= yi < H: E[yi, xi] = max(E[yi, xi], 0.18)

    # beam
    if beam_on:
        ext, env = bp
        xend = int(ox + (XI - ox) * ext)
        y0 = oy
        xs = np.arange(int(ox), xend + 1)
        rel = xs - ox
        pulse = np.maximum(0, np.sin(rel * 0.22 - f * 1.9)) ** 6
        base = 4.6 * env * (1 + 0.18 * np.sin(rel * 0.45 - f * 3.1) + 0.12 * np.sin(rel * 0.13 + f * 1.3) + 0.35 * pulse)
        base *= 0.45 + 0.55 * np.clip(rel / 12, 0, 1)
        wu = base * (1 + np.array([rng.uniform(-0.22, 0.22) for _ in xs]))
        wl = base * (1 + np.array([rng.uniform(-0.22, 0.22) for _ in xs]))
        keep = np.ones(len(xs), bool)
        if f > 45:  # dissipation breaks the beam apart
            thr = (f - 45) / 6
            n = np.array([rng.random() for _ in rel]) * 0.6 + 0.4 * (np.sin(rel * 0.11 + f) * 0.5 + 0.5)
            keep = n > thr * 0.95
            for i in np.where(~keep)[0][::3]:
                spawn(xs[i], y0 + rng.uniform(-3, 3), rng.uniform(-0.3, 0.6), rng.uniform(-1.2, -0.2), rng.randint(6, 14), rng.uniform(0.5, 0.9))
        for i, x in enumerate(xs):
            if not keep[i] or x >= W: continue
            dy = YY[:, 0] - y0
            ratio = np.where(dy < 0, -dy / (wu[i] + 2.5), dy / (wl[i] + 2.5))
            col = np.where(ratio < 1, 1.08 * (1 - np.clip(ratio, 0, 1) ** 1.6) + 0.08 * pulse[i], 0)
            E[:, x] = np.maximum(E[:, x], np.clip(col, 0, 1.1) * (0.6 + 0.4 * env))
        # light on environment
        inx = (XX >= ox) & (XX <= xend)
        L += 0.9 * env * np.exp(-np.abs(YY - y0) / 16) * inx
        L += 0.6 * env * np.exp(-np.hypot(XX - xend, YY - y0) / 14)
        glow = env
        # muzzle flare with rotating star
        D = np.hypot(XX - ox, YY - oy)
        E = np.maximum(E, np.clip(1.2 - D / (8.5 + 1.5 * math.sin(f * 2.1)), 0, 1.1) * env)
        a = (f % 2) * math.pi / 4
        for k in range(4):
            ang = a + k * math.pi / 2; ln = 9 + 4 * ((f + k) % 3)
            for r in range(3, int(ln * env) + 1):
                x, y = int(round(ox + r * math.cos(ang))), int(round(oy + r * math.sin(ang)))
                if 0 <= x < W and 0 <= y < H: E[y, x] = max(E[y, x], 0.95 - r / ln * 0.55)
        # crackling arcs
        if f <= 47:
            for _ in range(rng.randint(3, 5)):
                xa = rng.uniform(ox + 4, xend - 8); xb = min(xa + rng.uniform(12, 36), xend)
                sa, sb = rng.choice((-1, 1)), rng.choice((-1, 1))
                ya = y0 + sa * (4 * env + rng.uniform(1, 8)); yb = y0 + sb * (4 * env + rng.uniform(1, 8))
                pts = bolt(xa, ya, xb, yb, 6)
                raster_bolt(E, pts)
                if rng.random() < 0.5:
                    mx, my = pts[len(pts) // 2]
                    raster_bolt(E, bolt(mx, my, mx + rng.uniform(4, 10), my + rng.choice((-1, 1)) * rng.uniform(4, 9), 3, 3), 0.85, 0.4)
            if f >= 23 and rng.random() < 0.35:  # ground strike
                gx = rng.uniform(ox + 20, xend - 10)
                raster_bolt(E, bolt(gx, y0 + 4, gx + rng.uniform(-8, 8), FY, 5))
                for _ in range(6):
                    spawn(gx, FY - 1, rng.uniform(-1.5, 1.5), rng.uniform(-2.2, -0.6), rng.randint(5, 10), 0.85, g=0.25)
            # edge sparks
            for _ in range(5):
                x = rng.uniform(ox + 6, xend); sgn = rng.choice((-1, 1))
                spawn(x, y0 + sgn * 4 * env, rng.uniform(0.3, 2.0), sgn * rng.uniform(0.4, 1.6), rng.randint(5, 11), rng.uniform(0.6, 1.0))
        # impact
        if ext >= 1.0 and f <= 48:
            D = np.hypot(XX - xend, YY - y0)
            rimp = (7 + 2.5 * math.sin(f * 2.7) + rng.uniform(-1, 1)) * env
            E = np.maximum(E, np.clip(1.2 - D / max(rimp, 1), 0, 1.1) * (XX <= xend + 1))
            for k in range(7):
                ang = math.pi / 2 + (k / 6) * math.pi + rng.uniform(-0.2, 0.2)
                ln = rng.uniform(7, 16) * env
                raster_bolt(E, bolt(xend, y0, xend + ln * math.cos(ang), y0 + ln * math.sin(ang), 3, 2), 0.9, 0.45)
            for _ in range(4):
                spawn(xend - 1, y0 + rng.uniform(-3, 3), rng.uniform(-3.2, -0.8), rng.uniform(-2.5, 1.0), rng.randint(8, 16), rng.uniform(0.7, 1.0), g=0.18)
            if f % 3 == 0:
                spawn(xend - 3, y0 - 4, rng.uniform(-0.4, 0.1), -0.5, 16, 0.24, kind='smoke')
        elif ext < 1.0:  # leading head
            D = np.hypot(XX - xend, YY - y0)
            E = np.maximum(E, np.clip(1.15 - D / 6, 0, 1.1))
    if 49 <= f <= 58 and f % 2 == 0:
        spawn(XI - 3, oy - 3, rng.uniform(-0.4, 0.1), -0.45, 14, 0.22, kind='smoke')
        spawn(ox + 1, oy - 2, rng.uniform(-0.2, 0.2), -0.4, 10, 0.2, kind='smoke')

    # particles update and draw
    for p in parts[:]:
        if p['kind'] == 'mote':
            dx, dy = ox - p['x'], oy - p['y']; dist = math.hypot(dx, dy) + 1e-6
            p['vx'] = dx / dist * 2.6 - dy / dist * 1.2; p['vy'] = dy / dist * 2.6 + dx / dist * 1.2
            if dist < 3: p['life'] = 0
        p['x'] += p['vx']; p['y'] += p['vy']; p['vy'] += p['g']; p['life'] -= 1
        if p['kind'] == 'smoke': p['vx'] *= 0.95
        if p['y'] >= FY and p['g'] > 0: p['y'] = FY - 1; p['vy'] *= -0.4; p['vx'] *= 0.6
        if p['life'] <= 0: parts.remove(p); continue
        k = p['life'] / p['max']
        x, y = int(round(p['x'])), int(round(p['y']))
        if p['kind'] == 'smoke':
            r = 2 + (1 - k) * 3
            m = np.hypot(XX - p['x'], YY - p['y']) < r
            E[m] = np.maximum(E[m], p['e'] * (0.5 + 0.5 * k))
            continue
        v = p['e'] * (0.45 + 0.55 * k)
        if 0 <= x < W and 0 <= y < H:
            E[y, x] = max(E[y, x], v)
            if k > 0.6 and p['kind'] == 'spark':
                tx, ty = int(round(p['x'] - p['vx'])), int(round(p['y'] - p['vy']))
                if 0 <= tx < W and 0 <= ty < H: E[ty, tx] = max(E[ty, tx], v * 0.6)

    # ---------- composite ----------
    img = np.zeros((H, W, 3)) if nobg else BG.copy()
    if not nobg:
        _bg_pass = True
        tf = 0.75 + 0.25 * math.sin(f * 1.7) * math.sin(f * 0.6)
        Dt = np.hypot(XX - 10, YY - 33)
        warm = np.floor(np.clip(0.55 * tf * np.exp(-Dt / 13) * (1 - 0.6 * glow), 0, 1) * 4 + BY) / 4
        img += warm[..., None] * np.array([0.22, 0.09, 0.02])
        floorboost = np.where(YY >= FY, 1.6, 1.0)
        lit = np.floor(np.clip(L * floorboost, 0, 1.2) * 4 + BY) / 4
        img += lit[..., None] * np.array([0.04, 0.12, 0.30])
        if f == 21: img = img * 0.55 + 0.45 * np.array(hx('3060b0'))
        if f == 22: img = img * 0.8 + 0.2 * np.array(hx('3060b0'))
        # torch flame
        fl = [(10, 35, 'ffd060'), (10, 34, 'f08828'), (9, 35, 'f08828'), (11, 35, 'b04818'), (10, 36, 'f08828'),
              (9, 36, 'b04818'), (11, 36, 'b04818'), (10, 33 - (f % 3 == 0), 'b04818'), (10 + (f % 2), 32, '5a2010')]
        for x, y, c in fl: img[y, x] = hx(c)
        # wizard shadow
        sw = 9 + (6 if beam_on else 0)
        for x in range(WX + 1 - (6 if beam_on else 0), WX + 17):
            img[FY, x] = hx('1a1830'); img[FY + 1, x] = img[FY + 1, x] * 0.6 if x > WX - 2 else img[FY + 1, x]
    # sprite
    oyb = WY + bob
    for r, row in enumerate(SPR):
        lastc = None
        for c, ch in enumerate(row):
            if ch == '.': continue
            x, y = WX + c + (lean if r < 26 else 0), oyb + r - (1 if lean < 0 and r < 10 else 0)
            img[y, x] = C[ch]
            if ch not in 'Oe': lastc = (x, y)
        if lastc and glow > 0.2:  # rim light from the beam
            img[lastc[1], lastc[0]] = hx('5ad0ff' if glow > 0.55 else '2a90ff')
    # arm + staff
    for x, y in line(sx, sy, hxp, hyp):
        for ox2 in (-1, 0, 1):
            for oy2 in (-1, 0, 1):
                img[y + oy2, x + ox2] = C['O']
    for x, y in line(sx, sy, hxp, hyp):
        img[y, x] = C['b']; img[y - 1, x] = C['c']
    sp = line(*butt, *top)
    perp = (1, 0) if abs(d[1]) > abs(d[0]) else (0, 1)
    for x, y in sp:
        for ox2, oy2 in ((0, 0), (1, 0), (-1, 0), (0, 1), (0, -1), perp, (perp[0] + 1, perp[1]), (perp[0], perp[1] + 1)):
            if 0 <= x + ox2 < W and 0 <= y + oy2 < H: img[y + oy2, x + ox2] = C['O']
    for i, (x, y) in enumerate(sp):
        if 0 <= x < W and 0 <= y < H: img[y, x] = hx('9a6434' if i % 5 else '6a4022')
        if 0 <= x + perp[0] < W and 0 <= y + perp[1] < H: img[y + perp[1], x + perp[0]] = hx('3a2414')
    # gold prongs + orb
    tx, ty = top
    for s_ in (-1, 1):
        px, py = tx - 2 * d[0] + s_ * 3 * -d[1], ty - 2 * d[1] + s_ * 3 * d[0]
        for x, y in line(tx - 4 * d[0], ty - 4 * d[1], px, py):
            if 0 <= x < W and 0 <= y < H: img[y, x] = hx('c8a040')
        if 0 <= int(round(px)) < W and 0 <= int(round(py)) < H: img[int(round(py)), int(round(px))] = hx('f0d070')
    D = np.hypot(XX - tx, YY - ty)
    img[D <= 3.2] = hx('08060e'); img[D <= 2.4] = hx('1a5ad0')
    img[(D <= 1.6)] = hx('2a90ff')
    hl = (int(round(tx + 1)), int(round(ty - 1)))
    if 0 <= hl[0] < W and 0 <= hl[1] < H: img[hl[1], hl[0]] = hx('a8f0ff')
    # hand
    hi, hj = int(round(hxp)), int(round(hyp))
    for x, y in ((hi, hj), (hi + 1, hj), (hi, hj + 1), (hi + 1, hj + 1)):
        img[y, x] = hx('e0a878') if (x, y) == (hi, hj) else hx('b07850')
    # effects
    E = np.clip(E, 0, 1.2)
    A = (img.sum(-1) > 0).astype(float) if nobg else np.ones((H, W))
    tint = (E > 0) & (E < RAMP[0][0])
    solid_t = tint & (A > 0)
    img[solid_t] += (E[solid_t] / RAMP[0][0])[:, None] * np.array([0.05, 0.14, 0.4])
    soft = tint & (A == 0)
    img[soft] = hx('2a90ff'); A[soft] = np.clip(E[soft] / RAMP[0][0], 0, 1) * 0.6
    for th, col in RAMP:
        img[E >= th] = col
    A[E >= RAMP[0][0]] = 1
    # shake
    if beam_on and 21 <= f <= 27:
        sh = [(1, 0), (-1, 1), (1, -1), (0, 1), (-1, 0), (1, 0), (0, -1)][f - 21]
        img = np.roll(img, sh, axis=(1, 0)); A = np.roll(A, sh, axis=(1, 0))
    # quantize to palette
    flat = np.clip(img, 0, 1).reshape(-1, 3)
    idx = np.argmin(((flat[:, None, :] - P[None]) ** 2).sum(-1), axis=1)
    idx = idx.reshape(H, W).astype(np.uint8)
    return (idx, A) if nobg else idx

def main(out='wizard_beam.gif'):
    frames, durs = [], []
    pal = (np.round(P * 255).astype(int)).flatten().tolist()
    for f in range(NF):
        im = Image.fromarray(render(f), 'P'); im.putpalette(pal)
        frames.append(im.resize((W * SCALE, H * SCALE), Image.NEAREST))
        durs.append(70 if f in (15, 16, 17) else 50 if f == 21 else 40)
    frames[0].save(out, save_all=True, append_images=frames[1:], duration=durs, loop=0, disposal=1, optimize=False)
    sheet = Image.new('P', (W * 10, H * 6)); sheet.putpalette(pal)
    for i, fr in enumerate(frames):
        sheet.paste(fr.resize((W, H), Image.NEAREST), ((i % 10) * W, (i // 10) * H))
    sheet.resize((W * 10 * 2 // 2, H * 6), Image.NEAREST).save('sheet.png')

if __name__ == '__main__':
    main()
